Python module that faciliates working with Spike2 data files exported to Matlab format.

Documentation for this project is available [here](https://martinheroux.github.io/spike2py/).
